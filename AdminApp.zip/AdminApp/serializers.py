from rest_framework import serializers
from .models import (PithamModel,ZonesModel,StatesModel,DistrictsModel,CountriesModel,
AdminsModel,RegistorForEventModel,EventsModel,MembershipModel)

class MembershipSerializer(serializers.ModelSerializer):
    class Meta:
        model = MembershipModel
        fields = '__all__'

class PithamSerializer(serializers.ModelSerializer):
    class Meta:
        model = PithamModel
        fields = '__all__'

class ZonesSerializer(serializers.ModelSerializer):
    class Meta:
        model = ZonesModel
        fields = '__all__'

class StatesSerializer(serializers.ModelSerializer):
    class Meta:
        model = StatesModel
        fields = '__all__'

class DistrictsSerializer(serializers.ModelSerializer):
    class Meta:
        model = DistrictsModel
        fields = '__all__'

class AdminsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdminsModel
        fields = "__all__"


class CountriesSerializer(serializers.ModelSerializer):
    class Meta:
        model = CountriesModel
        fields = '__all__'

    def create(self, validated_data):
        return Countries.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.country_name = validated_data.get('country_name', instance.country_name)
        instance.save()
        return instance


class RegistorForEventSerializer(serializers.ModelSerializer):
    class Meta:
        model = RegistorForEventModel
        fields = '__all__'

    def create(self, validated_data):
        print("validated_data::",validated_data)
        return RegistorForEventModel.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.event_id = validated_data.get('event_id', instance.event_id)
        instance.participant_name = validated_data.get('participant_name', instance.participant_name)
        instance.participant_phone = validated_data.get('participant_phone', instance.participant_phone)
        instance.participant_email = validated_data.get('participant_email', instance.participant_email)
        instance.participant_city = validated_data.get('participant_city', instance.participant_city)
        instance.participant_country = validated_data.get('participant_country', instance.participant_country)
        instance.participant_state = validated_data.get('participant_state', instance.participant_state)
        instance.participant_district = validated_data.get('participant_district', instance.participant_district)
        instance.participant_pincode = validated_data.get('participant_pincode', instance.participant_pincode)
        instance.attended_before = validated_data.get('attended_before', instance.attended_before)
        instance.participant_gender = validated_data.get('participant_gender', instance.participant_gender)
        instance.participant_pitham = validated_data.get('participant_pitham', instance.participant_pitham)
        instance.participant_alternate = validated_data.get('participant_alternate', instance.participant_alternate)
        instance.participant_dob = validated_data.get('participant_dob', instance.participant_dob)
        instance.participant_surname = validated_data.get('participant_surname', instance.participant_surname)
        instance.participant_health = validated_data.get('participant_health', instance.participant_health)
        instance.save()
        return instance


class EventsSerializer(serializers.ModelSerializer):
    class Meta:
        model = EventsModel
        fields = "__all__"

    def create(self, validated_data):
        return Events.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.event_name = validated_data.get('event_name', instance.event_name)
        instance.event_description = validated_data.get('event_description', instance.event_description)
        instance.event_start_date = validated_data.get('event_start_date', instance.event_start_date)
        instance.event_end_date = validated_data.get('event_end_date', instance.event_end_date)
        instance.event_reg_start_date = validated_data.get('event_reg_start_date', instance.event_reg_start_date)
        instance.event_reg_end_date = validated_data.get('event_reg_end_date', instance.event_reg_end_date)
        instance.event_duration = validated_data.get('event_duration', instance.event_duration)
        instance.event_nature = validated_data.get('event_nature', instance.event_nature)
        instance.event_category = validated_data.get('event_category', instance.event_category)
        instance.event_type = validated_data.get('event_type', instance.event_type)
        instance.event_registration = validated_data.get('event_registration', instance.event_registration)
        instance._type = validated_data.get('_type', instance._type)
        instance.event_pitham = validated_data.get('event_pitham', instance.event_pitham)
        instance.event_shortname = validated_data.get('event_shortname', instance.event_shortname)
        instance.save()
        return instance
