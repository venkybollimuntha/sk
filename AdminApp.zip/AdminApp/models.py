from django.db import models

class TableMemberCommunication(models.Model):
    mem_id = models.CharField(max_length=20, primary_key=True)
    mem_phone = models.CharField(max_length=20)
    mem_email = models.TextField()
    mem_whatsapp = models.CharField(max_length=20)
    mem_phone2 = models.CharField(max_length=20)
    mem_houseno = models.TextField()
    mem_address = models.TextField()
    mem_landmark = models.TextField(blank=True, null=True)
    mem_locality = models.TextField()
    mem_city = models.TextField()
    mem_pincode = models.CharField(max_length=20)
    mem_district = models.CharField(max_length=30)
    mem_state = models.CharField(max_length=30)
    mem_country = models.CharField(max_length=30)
    mem_zone = models.CharField(max_length=30)





class TableMembers(models.Model):
    mem_id = models.CharField(max_length=20, unique=True)
    m_id = models.CharField(max_length=20)
    mem_creation = models.DateTimeField(auto_now_add=True)
    razorpay_order_id = models.CharField(max_length=50, default='NA')
    razorpay_payment_id = models.CharField(max_length=50, default='NA')
    tran_status = models.CharField(max_length=10)
    tran_time = models.DateTimeField(auto_now_add=True)
    payment_mode = models.CharField(max_length=15)
    transaction_reference = models.CharField(max_length=50, default='NA')
    memdership_status = models.CharField(max_length=20, default='NA')
    manual_receipt = models.IntegerField(null=True, unique=True)
    auto_receipt = models.IntegerField(null=True, unique=True)
    offline_tran_remarks = models.TextField(null=True)
    table_memberscol = models.CharField(max_length=45, null=True)
    
    class Meta:
        db_table = 'table_members'


class TableMembersOld(models.Model):
    mem_id = models.AutoField(primary_key=True)
    m_id = models.CharField(max_length=50)
    mem_doa = models.DateField()
    mem_title = models.CharField(max_length=15)
    mem_surname = models.CharField(max_length=30)
    mem_name = models.CharField(max_length=50)
    mem_co = models.CharField(max_length=10)
    mem_coname = models.CharField(max_length=50)
    mem_dob = models.DateField()
    mem_occupation = models.CharField(max_length=50)
    mem_department = models.CharField(max_length=50, null=True, blank=True)
    mem_org = models.CharField(max_length=50, null=True, blank=True)
    mem_flatno = models.CharField(max_length=10)
    mem_add1 = models.CharField(max_length=50)
    mem_locality = models.CharField(max_length=50)
    mem_city = models.CharField(max_length=50)
    mem_state = models.CharField(max_length=50)
    mem_zipcode = models.CharField(max_length=10)
    mem_country = models.CharField(max_length=50)
    mem_phone1 = models.CharField(max_length=10)
    mem_phone2 = models.CharField(max_length=10, null=True, blank=True)
    mem_email = models.CharField(max_length=50, null=True, blank=True)
    mem_whatsapp = models.CharField(max_length=10)
    mem_reason = models.CharField(max_length=100)
    mem_reference = models.CharField(max_length=100)
    mem_volunteer = models.BooleanField(default=True)
    mem_designation = models.CharField(max_length=50, null=True, blank=True)
    razorpay_order_id = models.CharField(max_length=50)
    razorpay_payment_id = models.CharField(max_length=50)
    tran_status = models.CharField(max_length=10)
    tran_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'table_members_old'


######################## The below models are working with UAT DB ####################
class MemberDetails(models.Model):
    mem_id = models.CharField(max_length=20, primary_key=True)
    mem_title = models.CharField(max_length=10)
    mem_fname = models.CharField(max_length=30)
    mem_lname = models.CharField(max_length=30)
    mem_dob = models.DateTimeField()
    mem_profession = models.CharField(max_length=30)
    mem_designation = models.CharField(max_length=30)
    mem_industry = models.CharField(max_length=30)
    mem_organization = models.CharField(max_length=30)
    mem_photo = models.BinaryField()
    mem_qualification = models.CharField(max_length=45)
    mem_gender = models.CharField(max_length=10)
    mem_qualificationdetail = models.CharField(max_length=45)
    mem_cof = models.CharField(max_length=45, null=True, blank=True)
    mem_co_details = models.CharField(max_length=45, null=True, blank=True)
    mem_occupation = models.CharField(max_length=45, null=True, blank=True)
    mem_salary = models.TextField()
    
    def __str__(self):
        return self.mem_id

# membershipList
class MembershipModel(models.Model):
    m_id = models.CharField(max_length=15, primary_key=True)
    m_type = models.CharField(max_length=15)
    m_tenure = models.IntegerField()
    m_price = models.IntegerField()
    m_name = models.CharField(max_length=50)
    m_desc = models.CharField(max_length=100)
    m_code = models.CharField(max_length=2, default='L')

    class Meta:
        db_table = 'table_membership'

class PithamModel(models.Model):
    pitam_id = models.AutoField(primary_key=True)
    pitam_name = models.TextField()
    pitam_contact = models.TextField()
    pitam_zone = models.IntegerField(null=True)
    pitam_district = models.IntegerField(null=True)
    pitam_state = models.IntegerField(null=True)
    pitam_coordinator = models.TextField()

    class Meta:
        db_table = 'table_pithams'

class ZonesModel(models.Model):
    zone_id = models.AutoField(primary_key=True)
    zone_name = models.TextField()
    zone_district = models.TextField()
    zone_district_id = models.IntegerField(null=True)

    class Meta:
        db_table = 'table_zones'

class StatesModel(models.Model):
    state_id = models.AutoField(primary_key=True)
    state_name = models.CharField(max_length=45)
    country_id = models.CharField(max_length=45)

    class Meta:
        db_table = 'table_states'

class DistrictsModel(models.Model):
    district_id = models.AutoField(primary_key=True)
    district_name = models.CharField(max_length=45)
    state_id = models.CharField(max_length=45)

    class Meta:
        db_table = 'table_districts'

class CountriesModel(models.Model):
    country_id = models.AutoField(primary_key=True)
    country_name = models.CharField(max_length=45)

    class Meta:
        db_table = 'table_countries'


class AdminsModel(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=45)
    password = models.CharField(max_length=100)
    type = models.CharField(max_length=45)

    class Meta:
        db_table = 'table_admins'


class RegistorForEventModel(models.Model):
    # registration_id = models.AutoField(primary_key=True)
    event_id = models.IntegerField()
    participant_name = models.CharField(max_length=45)
    participant_phone = models.CharField(max_length=15)
    participant_email = models.CharField(max_length=60)
    participant_city = models.CharField(max_length=30)
    participant_country = models.CharField(max_length=45)
    participant_state = models.CharField(max_length=45)
    participant_district = models.CharField(max_length=45)
    participant_pincode = models.CharField(max_length=45)
    attended_before = models.CharField(max_length=5,  default='1')
    participant_gender = models.CharField(max_length=45)
    participant_pitham = models.CharField(max_length=60, default='0')
    participant_alternate = models.CharField(max_length=15, null=True, blank=True)
    participant_dob = models.DateTimeField(null=True, blank=True)
    participant_surname = models.CharField(max_length=45,  null=True, blank=True)
    participant_health = models.CharField(max_length=80, null=True, blank=True)

    class Meta:
        db_table = 'table_event_registrar'

# events
class EventsModel(models.Model):
    event_id = models.AutoField(primary_key=True)
    event_name = models.CharField(max_length=45)
    event_description = models.CharField(max_length=100, null=True, blank=True)
    event_start_date = models.DateTimeField(auto_now_add=True)
    event_end_date = models.DateTimeField(auto_now_add=True)
    event_reg_start_date = models.DateTimeField(auto_now_add=True)
    event_reg_end_date = models.DateTimeField(auto_now_add=True)
    event_duration = models.CharField(max_length=50)
    event_nature = models.CharField(max_length=45)
    event_category = models.CharField(max_length=45)
    event_type = models.CharField(max_length=45)
    event_registration = models.BooleanField(default=True)
    _type = models.CharField(max_length=45)
    event_pitham = models.TextField()
    event_shortname = models.CharField(max_length=45)

    class Meta:
        db_table = 'table_events'

################## IGNORE these two models ############################

class Record(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    address = models.CharField(max_length=200)
    approved = models.BooleanField(default=False)
    
    def __str__(self):
        return self.name


class Customer(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField()
    phone_number = models.CharField(max_length=20)
    country = models.CharField(max_length=50)
    amount = models.DecimalField(max_digits=8, decimal_places=2)
    first_level_approval = models.BooleanField(default=False)
    second_level_approval = models.BooleanField(default=False)

    def __str__(self): 
        return self.email