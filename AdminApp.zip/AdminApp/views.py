# Django Imports
from django.shortcuts import render, redirect,get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.contrib import admin

# Python specific imports
import openpyxl


# REST API imports
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.exceptions import APIException

# Application Imports
from .forms import ContactForm
from .models import (PithamModel,ZonesModel,StatesModel,DistrictsModel,CountriesModel,
AdminsModel,RegistorForEventModel,EventsModel,MembershipModel)

from .serializers import (PithamSerializer,
                            ZonesSerializer,
                            StatesSerializer,
                            DistrictsSerializer,
                            CountriesSerializer,
                            AdminsSerializer,
                            RegistorForEventSerializer,
                            EventsSerializer,
                            MembershipSerializer)



def index(request):
	return HttpResponse("Hey! Its working Man!")


@csrf_exempt
def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # Create a new Customer object with the form data
            customer = Customer(
                first_name=form.cleaned_data['first_name'],
                last_name=form.cleaned_data['last_name'],
                email=form.cleaned_data['email'],
                phone_number=form.cleaned_data['phone_number'],
                country=form.cleaned_data['country'],
                amount=form.cleaned_data['amount'],
            )
            # Save the customer object to the database
            customer.save()
            return redirect('form_success')
    else:
        form = ContactForm()
    return render(request, 'contact.html', {'form': form})

def form_success(request):
    return render(request, 'form_success.html')

@csrf_exempt
def callback(request):
	print("request received:::",request)
	print(request.headers)
	print(request.body)
	print(dir(request))
	return HttpResponse("UPI response returned")



def get_pitham_list(request):
    try:
        result = PithamModel.objects.all()
        serializer = PithamSerializer(result,many=True)
        json_string = serializer.data
        return JsonResponse(json_string,safe=False)
    except Exception as e:
        raise e


def get_regions_list(request):
    try:
        result = PithamModel.objects.all()
        serializer = PithamSerializer(result,many=True)
        json_string = serializer.data
        return JsonResponse(json_string,safe=False)
    except Exception as e:
        raise e

def get_zone_list(request):
    try:
        result = ZonesModel.objects.all()
        serializer = ZonesSerializer(result,many=True)
        json_string = serializer.data
        return JsonResponse(json_string,safe=False)
    except Exception as e:
        raise e


def get_state_list(request):
    try:
        result = StatesModel.objects.all()
        serializer = StatesSerializer(result,many=True)
        json_string = serializer.data
        return JsonResponse(json_string,safe=False)
    except Exception as e:
        raise e


def get_district_list(request):
    try:
        result = DistrictsModel.objects.all()
        serializer = DistrictsSerializer(result,many=True)
        return JsonResponse(serializer.data,safe=False)
    except Exception as e:
        raise e

def get_admins_list(request):
    try:
        result = AdminsModel.objects.all()
        serializer = AdminsSerializer(result,many=True)
        json_string = serializer.data
        return JsonResponse(json_string,safe=False)
    except Exception as e:
        raise e


class MembershipView(APIView):
    def get(self,request,pk=None):
        try:
            if pk == None:
                result = MembershipModel.objects.all()
                serializer = MembershipSerializer(result,many=True)
            else:
                result = MembershipModel.objects.get(pk=pk)
                serializer = MembershipSerializer(result)

            return JsonResponse(serializer.data,safe=False)
        except Exception as e:
            raise APIException(str(e))

class Countries(APIView):
    def get(self,request):
        try:
            result = Countries.objects.all()
            serializer = CountriesSerializer(result,many=True)
            json_string = serializer.data
            return JsonResponse(json_string,safe=False)
        except Exception as e:
            raise APIException(str(e))

    def post(self,request):
        try:
            print(request.data)
            serializer = CountriesSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=201)
            return Response(serializer.errors, status=400)
        except Exception as e:
            raise APIException(str(e))


class EventsView(APIView):
    def get(self,request,pk=None):
        try:
            if pk == None:
                result = EventsModel.objects.all()
                serializer = EventsSerializer(result,many=True)
            else:
                result = EventsModel.objects.get(pk=pk)
                serializer = EventsSerializer(result)

            return JsonResponse(serializer.data,safe=False)
        except EventsModel.DoesNotExist:
            raise APIException("Event Registrar not found")
        except Exception as e:
            raise APIException(str(e))

    def post(self,request):
        try:
            serializer = EventsSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            raise APIException(str(e))

    def put(self, request, pk=None):
        try:
            if pk is None:
                return Response({'error': 'Please provide a valid primary key to update event'}, status=status.HTTP_400_BAD_REQUEST)
            event_registrar = EventsModel.objects.get(pk=pk)
            serializer = EventsSerializer(event_registrar, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except EventsModel.DoesNotExist:
            raise APIException("Event was not found")
        except Exception as e:
            raise APIException(str(e))


class EventRegistration(APIView):
    def get(self, request, pk=None):
        try:
            if pk is None:
                event_registrars = RegistorForEventModel.objects.all()
                serializer = RegistorForEventSerializer(event_registrars, many=True)
            else:
                event_registrar = RegistorForEventModel.objects.get(pk=pk)
                serializer = RegistorForEventSerializer(event_registrar)
            return Response(serializer.data)
        except RegistorForEventModel.DoesNotExist:
            raise APIException("Event Registrar not found")
        except Exception as e:
            raise APIException(str(e))

    def post(self, request):
        try:
            data = request.data
            validated_data = {}
            validated_data['event_id'] = data['event_id']
            validated_data['participant_name'] = data['reg_name']
            validated_data['participant_phone'] = data['reg_phone']
            validated_data['participant_email'] = data['reg_email']
            validated_data['participant_city'] = data['reg_city']
            validated_data['participant_country'] = data['reg_country']
            validated_data['participant_state'] = data['reg_state']
            validated_data['participant_district'] = data['reg_district']
            validated_data['participant_pincode'] = data['reg_pincode']
            validated_data['attended_before'] = data['reg_prev_attend']
            validated_data['participant_gender'] = data['reg_gender']
            validated_data['participant_pitham'] = data['reg_pitham']
            validated_data['participant_alternate'] = data['reg_alternate']
            validated_data['participant_dob'] = data['mem_dob']
            validated_data['participant_surname'] = data['reg_surname']
            validated_data['participant_health'] = data['reg_health']
            serializer = RegistorForEventSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            raise APIException(str(e))

    def put(self, request, pk=None):
        try:
            if pk is None:
                return Response({'error': 'Please provide a valid primary key to update registration event'}, status=status.HTTP_400_BAD_REQUEST)
            event_registrar = RegistorForEventModel.objects.get(pk=pk)
            serializer = RegistorForEventSerializer(event_registrar, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except RegistorForEventModel.DoesNotExist:
            raise APIException("Event Registrar not found")
        except Exception as e:
            raise APIException(str(e))


