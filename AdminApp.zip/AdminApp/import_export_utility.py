from import_export import resources
from .models import PithamModel,RegistorForEventModel

class PithamModelResource(resources.ModelResource):
    class Meta:
        model = PithamModel

class RegistorForEventResource(resources.ModelResource):
    class Meta:
        model = RegistorForEventModel