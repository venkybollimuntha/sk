from django import forms

class ContactForm(forms.Form):
    first_name = forms.CharField(max_length=50)
    last_name = forms.CharField(max_length=50)
    email = forms.EmailField()
    phone_number = forms.CharField(max_length=20)
    country = forms.CharField(max_length=50)
    amount = forms.DecimalField(max_digits=10, decimal_places=2)
    