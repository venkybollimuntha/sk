"""VenkyProject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
from django.views.decorators.csrf import csrf_exempt

urlpatterns = [
    path('', views.index,name="index"),
    path('form_submit/', views.contact,name="form_submit"),
    path('form_success', views.form_success, name='form_success'),
    path('callback', views.callback, name='callback'),
    path('zone', views.get_zone_list, name='zone'),
    path('state', views.get_state_list, name='state'),
    path('district', views.get_district_list, name='district'),
    path('country', views.Countries.as_view(), name='country'),
    path('admins', views.get_admins_list, name='admin'),
    path('region', views.get_regions_list, name='region'),

    path('pithamList', views.get_pitham_list, name='pitam'),
    path('registerforevent', csrf_exempt(views.EventRegistration.as_view()), name='event_registrar'),
    path('registerforevent/<int:pk>', csrf_exempt(views.EventRegistration.as_view()),name="event_registrar_id"),
    path('events', views.EventsView.as_view(),name="events"),
    path('events/<int:pk>', views.EventsView.as_view(),name="events_id"),
    path('membershipList', views.MembershipView.as_view(),name="membership_list"),
    path('membershipList/<str:pk>', views.MembershipView.as_view(),name="membership_list_id"),
]


