from django.contrib import admin
from .models import Record,Customer, PithamModel,RegistorForEventModel
from django.http import HttpResponse
from django.contrib.auth.models import Group
from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied
from import_export import resources
from .import_export_utility import PithamModelResource,RegistorForEventResource 
import openpyxl
from import_export.admin import ImportExportModelAdmin



class PithamAdmin(ImportExportModelAdmin,admin.ModelAdmin):
    list_display = ('pitam_id', 'pitam_name', 'pitam_contact', 'pitam_zone', 'pitam_district',"pitam_state","pitam_coordinator")
    list_filter = ('pitam_id','pitam_name', 'pitam_contact')
    resource_class = PithamModelResource

    def has_add_permission(self, request):
        # This method is to restrict the Creation of the records from admin console
        return True
    def has_change_permission(self, request, obj=None):
        return True
    
    def has_delete_permission(self, request, obj=None):
        return True
    
admin.site.register(PithamModel,PithamAdmin)


class RegistorForEventAdmin(ImportExportModelAdmin,admin.ModelAdmin):
    list_display = ('registration_id', 'event_id', 'participant_name', 'participant_email', 'participant_phone', 'participant_city', 'participant_country', 'participant_state', 'participant_district', 'participant_pincode', 'attended_before', 'participant_gender', 'participant_pitham', 'participant_alternate', 'participant_dob', 'participant_surname', 'participant_health')
    resource_class = RegistorForEventResource

admin.site.register(RegistorForEventModel, RegistorForEventAdmin)


# class RecordAdmin(admin.ModelAdmin):
#     list_display = ('name', 'age', 'salary', 'address', 'approved')
#     list_filter = ('approved',)
#     actions = ['approve_records']

#     def approve_records(self, request, queryset):
#         queryset.update(approved=True)

#     approve_records.short_description = "Approve selected records"

# admin.site.register(Record, RecordAdmin)

# User = get_user_model()

# class SecondLevelApprovalAdmin(admin.ModelAdmin):
#     list_display = ('first_name', 'last_name', 'email', 'phone_number', 'country', 'amount', 'first_level_approval', 'second_level_approval')
#     list_filter = ('first_level_approval', 'second_level_approval')

    # def get_queryset(self, request):
    #     qs = super().get_queryset(request)
    #     user = request.user

    #     # Only show customers where first_level_approval is True and second_level_approval is False
    #     if user.groups.filter(name='Second Level Approver').exists():
    #         qs = qs.filter(first_level_approval=True, second_level_approval=False)

    #     return qs

# class CustomerAdmin(admin.ModelAdmin):
    # list_display = ('first_name', 'last_name', 'email', 'phone_number', 'country', 'amount', 'first_level_approval', 'second_level_approval')
    
    # def accept_first_level(self, request, queryset):
    #     queryset.update(first_level_approval=True)

    # def deny_first_level(self, request, queryset):
    #     queryset.update(first_level_approval=False)

    # def accept_second_level(self, request, queryset):
    #     queryset.update(second_level_approval=True)

    # def deny_second_level(self, request, queryset):
    #     queryset.update(second_level_approval=False)

    # actions = [accept_first_level, deny_first_level, accept_second_level, deny_second_level]

# admin.site.unregister(Group)
# admin.site.register(Customer, CustomerAdmin)
# admin.site.register(Customer, SecondLevelApprovalAdmin)


User = get_user_model()

class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'phone_number', 'country', 'amount', 'first_level_approval', 'second_level_approval')
    list_filter = ('first_level_approval', 'second_level_approval')
    
    def accept_first_level(self, request, queryset):
        queryset.update(first_level_approval=True)

    def deny_first_level(self, request, queryset):
        queryset.update(first_level_approval=False)

    def accept_second_level(self, request, queryset):
        queryset.update(second_level_approval=True)

    def deny_second_level(self, request, queryset):
        queryset.update(second_level_approval=False)

    actions = [accept_first_level, deny_first_level, accept_second_level, deny_second_level]

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        user = User.objects.get(username=request.user)
        group = user.groups.first()
        
        if user.is_superuser:
            
            return qs

        elif group and group.name == 'First Level Adminstrator':
            print("inside second")
            # Second Level Administrators can see records with first_level_approval=True
            return qs.filter(first_level_approval=False, second_level_approval=False)

        elif group and group.name == 'Second Level Adminstrator':
            print("inside second")
            # Second Level Administrators can see records with first_level_approval=True
            return qs.filter(first_level_approval=True, second_level_approval=False)
        else:
            # Regular users can't see any records
            raise PermissionDenied("You don't have permissions to view this table")


# admin.site.register(Customer, CustomUserAdmin)
# admin.site.register(Customer, CustomUserAdmin)

