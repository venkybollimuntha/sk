from django.http import JsonResponse
from django.views.decorators.http import require_http_methods,require_POST
from django.views.decorators.csrf import csrf_exempt
from myapp.models import RegionModel,PithamModel,MemberShipModel
import razorpay
from decouple import config

from django.db import connection
from django.core.mail import EmailMessage
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

region_model = RegionModel()

@require_http_methods(['GET'])
def get_regions_list(request):
    try:
        result = region_model.get_regions()
        return JsonResponse(result, safe=False)
    except Exception as e:
        raise e


pitham_model = PithamModel()

@require_http_methods(['GET'])
def get_pitham_list(request):
    try:
        result = pitham_model.get_pitham_list()
        return JsonResponse(result, safe=False)
    except Exception as e:
        raise e

razorpay_client = razorpay.Client(auth=(config('RAZORPAY_KEY_ID'), config('RAZORPAY_SECRET')))

@csrf_exempt
@require_POST
def process_payment(request):
    payment_capture = 1
    amount = request.POST.get('amount')
    currency = "INR"

    options = {
        'amount': amount * 100,
        'currency': currency,
        'payment_capture': payment_capture,
    }

    try:
        response = razorpay_client.order.create(options)
        return JsonResponse({
            'id': response.get('id'),
            'currency': response.get('currency'),
            'amount': response.get('amount'),
        })
    except Exception as e:
        return JsonResponse({'error': str(e)})


membership_model = MemberShipModel()

@require_http_methods(['POST'])
def get_membership_list(request):
    user_number = request.POST.get('userNumber')
    try:
        result = membership_model.get_membership_list()
        return JsonResponse(result, safe=False)
    except Exception as e:
        raise e



# class EventModel:
#     def __init__(self):
#         pass

#     def get_event_list(self):
#         with connection.cursor() as cursor:
#             cursor.execute('SELECT * from table_events')
#             result = cursor.fetchall()
#             return result

#     def get_event_by_id(self, ev_id):
#         with connection.cursor() as cursor:
#             cursor.execute('SELECT * from table_events where event_id = %s', [ev_id])
#             result = cursor.fetchone()
#             return result

#     def register_for_event(self, data):
#         event_id = data['event_id']
#         reg_name = data['reg_name']
#         reg_phone = data['reg_phone']
#         reg_email = data['reg_email']
#         reg_city = data['reg_city']
#         reg_country = data['reg_country']
#         reg_state = data['reg_state']
#         reg_district = data['reg_district']
#         reg_pincode = data['reg_pincode']
#         attended_before = data['attended_before']
#         reg_gender = data['reg_gender']
#         reg_alternate = data['reg_alternate']
#         reg_pitham = data['reg_pitham']
#         reg_dob = data['reg_dob']
#         reg_surname = data['reg_surname']
#         reg_health = data['reg_health']

#         with connection.cursor() as cursor:
#             cursor.execute('INSERT INTO table_event_registrar (`event_id`,`participant_name`,`participant_phone`,`participant_email`,`participant_city`,`participant_country`,`participant_state`,`participant_district`,`participant_pincode`,`attended_before`,`participant_gender`, `participant_alternate`, `participant_pitham`, `participant_dob`, `participant_surname`, `participant_health`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)', [event_id, reg_name, reg_phone, reg_email, reg_city, reg_country, reg_state, reg_district, reg_pincode, attended_before, reg_gender, reg_alternate, reg_pitham, reg_dob, reg_surname, reg_health])
#             cursor.execute('SELECT LAST_INSERT_ID()')
#             reg_id = cursor.fetchone()[0]

#         credentials = Credentials.from_authorized_user_info(info=None, scopes=['https://www.googleapis.com/auth/gmail.send'], token='access_token')
#         service = build('gmail', 'v1', credentials=credentials)
#         message = EmailMessage()
#         message.set_content('You have been registered for the event successfully.')
#         message['to'] = reg_email
#         message['subject'] = 'Registration confirmation'
#         create_message = {'raw': base64.urlsafe_b64encode(message.as_bytes()).decode()}
#         try:
#             send_message = (service.users().messages().send(userId="me", body=create_message).execute())
#             print(F'sent message to {reg_email} Message Id: {send_message["id"]}')
#         except HttpError as error:
#             print(F'An error occurred: {error}')
#             send_message = None
#         return reg_id


from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import MemberModel

memberModel = MemberModel()

@csrf_exempt
def get_members_list(request):
    if request.method == 'POST':
        user_number = request.POST.get('userNumber')
        try:
            result = memberModel.getMembersList()
            return JsonResponse(result, safe=False)
        except Exception as e:
            raise e

@csrf_exempt
def get_member_by_id(request):
    if request.method == 'POST':
        mem_id = request.POST.get('id')
        try:
            result = memberModel.getMemberById(mem_id)
            return JsonResponse(result, safe=False)
        except Exception as e:
            raise e

@csrf_exempt
def add_member(request):
    if request.method == 'POST':
        try:
            result = memberModel.addMember(request.POST)
            return JsonResponse(result, safe=False)
        except Exception as e:
            raise e

@csrf_exempt
def delete_member(request):
    if request.method == 'POST':
        try:
            result = memberModel.deleteMember(request.POST.get('id'))
            return JsonResponse(result, safe=False)
        except Exception as e:
            raise e

@csrf_exempt
def update_member(request):
    if request.method == 'POST':
        try:
            result = memberModel.updateMember(request.POST)
            return JsonResponse(result, safe=False)
        except Exception as e:
            raise e

from django.http import JsonResponse
from django.views import View
from .models import EventModel

eventModel = EventModel()

class EventController(View):
    def get(self, request):
        try:
            result = eventModel.getEventList()
            return JsonResponse(result, safe=False)
        except Exception as e:
            raise e

    def post(self, request):
        try:
            result = eventModel.registerForEvent(request.POST.dict())
            return JsonResponse(result, safe=False)
        except Exception as e:
            raise e

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.hashers import make_password, check_password
from .models import AuthModel
from express_validator import check, validationResult

auth_model = AuthModel()

@csrf_exempt
def create_admin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        hashed_password = make_password(password)
        data = {
            'user': username,
            'pwd': hashed_password
        }
        try:
            result = auth_model.create_admin(data)
            return JsonResponse(result)
        except Exception as e:
            raise e

@csrf_exempt
def admin_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        data = {
            'user': username,
            'pwd': password
        }
        try:
            user_exists = auth_model.check_admin(data)
            if len(user_exists) == 1:
                hashed_password = user_exists[0]['admin_password']
                pwd_match = check_password(password, hashed_password)
                if pwd_match:
                    return JsonResponse(user_exists)
                else:
                    return JsonResponse({'message': 'Login failed'})
            else:
                return JsonResponse({'message': 'User does not exist'})
        except Exception as e:
            raise e
